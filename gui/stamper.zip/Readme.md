
--------------------------------------------------------
            Example constructions workflow:
--------------------------------------------------------
Illustrated: https://imgur.com/a/BJiowXm

====  I want to build an above ground elliptical tower.  ====

==Workflow 1: simple

=Preparation
*Make sure your build site is clear of constructions, trees, and other junk that would interfere with normal construction placement.
*Make sure you have enough of the material you want to build with (eg. quartizite blocks). If you don't they'll just cancel the construction with a message and you'll have to re-stamp (or fill in with the normal way).
*This example assumes stamper is in it's default state (designation mode, no existing selection).

=In regular dig designation mode:
1. On some random underground patch, designate an ellipse[or whatever] of <h> channel designation to be the exterior walls.  [*digshape makes this easy]
2. Fill the shape with <d> dig designation to be the interior floors. [*with digshape, just use the flood command]
3. Place some stairways <i>

=Switch to stamper, (designation mode)
In the dfhack console (not the Ctrl-Shift-P prompt, it just makes a black screen) enter: gui/stamperc

1. Draw the select box around your designations. (If you've already got a selection made, use <s> to begin a new selection.
    1a. Move the cursor to one corner of the designation, press enter to mark
    1b. Move cursor to the opposite corner, press enter to make the selection
2. Move the view up to where you want to build the tower.  You should see your design in cyan moving with your cursor.
3. Switch stamper to constructions mode <f>
4. Change your material if desired
  4a. Change material, <SHIFT+F>. A popup appears, type in the material name (all caps). To find the material name, consult the wiki for the material, view the raw, and it's the name at the top like [INORGANIC:NATIVE_COPPER] -> NATIVE_COPPER (for the ore), or [PLANT:OAK] -> OAK, or [INORGANIC:COPPER] -> COPPER (for the metal)
  4b. Change the item type <SHIFT+B>. A popup appears, type in the item type you want (a list of valid entries is shown).
  NOTE: no error checking or consistency checking will be done (eg making vertical bars with limestone boulders), the placement will just silently fail. I assume you know what the thing you're trying to build needs. No harm should occur, worst case the construction designation will appear, but a dwarf will cancel it with no material available.
5. Press enter to stamp the constructions into the world. If the stamp is very large a small delay will occur as the jobs are generated. This seems to be less than the equivalent box-designate constructions. No progress indicatior will appear.

6. Exit stamper and designations menu, unpause, let the dwarves build. (you may need to unpause constructions if the dwarves interfere with each other, as normal)
7. Move up a z level, go back into stamper, align and place the next level of your tower.
  7a. You can press <b> to blink the stamp to make alignment easier, if it helps.
  NOTE: your dwarves may strand themselves by walking out along the wall and cutting off their retreat, then they'll cancel the builds adjacent. This is why the fancy features of stamper exist, and I'll demonstrate in workflow 2.
8. goto 6, repeat as desired.


==Workflow 2: Advanced options
This will be the same as workflow 1, but we'll add a little extra in to make the construction nicer.

We'll do a 5 level tower all at once, but you can skip multiple floors if you want.

=In regular dig designation mode:
Do regular designations 1..3 as per workflow 1.
NOTE: A great way to make walls in a shape is to make the shape of the whole thing as a solid designation of channel, select it as a stamp, shrink it once, convert it to dig, paste it.
4. For the outside wall corners, that when built above ground will be unreachable if built in the wrong order, pick one wall tile <h> that is orthogonal to a floor tile <d> to be our 'scaffolding' stage. We'll build this as floor first, then remove it, then build it as wall. Designate these as ramp <r>. A good choice are inside corners, but there's plenty of flexibility.
  WARNING: make sure there won't be any segments that are unsupported if all the <r> tiles are removed at the same time.
  NOTE: of course, if everything is nicely lined up on the layer below, the walls below will provide sufficient walkable places.
  NOTE: A doorway is left as an exercise to the reader. Perhaps using DownStair?

=Switch to stamper, (designation mode)
Do stamper steps 1..4 as workflow 1.
Press <f> to switch to construction mode, and move to an open spot on the surface.
Make sure you've cleared trees out first.

5. For the ground level, we can get to all the outside corner walls (r's in our pattern), so we'll place them as walls. Press <c> to open the paste as.. submenu.
  5a. press <r> to cycle what designated ramps will be pasted as until it turns up as floor.
  5b. lets change the updown stair to an upstair for the ground floor. Press <i> until it cycles to UpStair.
  5c. we'll build the floors in the first pass so dwarves can't strand themselves. Press <h> to cycle the walls to Skip/Ignore. This is more important on the higher floors.
  5d. Press <ESC> to return to the main stamper menu.
  NOTE: changing what things "paste as" does not modify the actual stamp. You can return stamper to designations mode to see it unchanged. Switching between designations and constructions, or making a new selection will not cause it to forget, though reloading the game will.

6. Press <ENTER> to stamp floor one of the tower into the world.
    NOTE: you could let the dwarves build this floor first, but it's not required. We can designate in open space using dfhack.
7. Move up a z level, open the paste as submenu <c>
  7a. Since we're no longer on the first floor, reset our updown stairs, press <SHIFT+I> (you could also just press <i> until it gets back to updown.
8. Press <ENTER> to stamp the brush.
  8a. move up a z level, and press <ENTER> again
  8b. do this for a few floors (make sure you have enough of the material you are using)
  NOTE: if you're having trouble aligning the brush on higher levels, press <ESC> to exit the paste as menu, then press <b> to blink the brush, and go back into the paste as menu <c>

9. Press <ESC> until you are back at the main DF menu, unpause and let them build.
    NOTE: they'll build on many levels at once rather than one at a time, but they can't get stuck because there are no walls being built yet.


11. Lets go back and place the walls we ignored. Open stamper and move the brush to the first floor.
  11a. Press <c> to open the "Paste as" submenu.
  11a. Press <SHIFT+H> to reset channel designations to paste as walls
  11b. Press <ESC> to exit this submenu
  NOTE: Constructions won't be placed where constructions already exist, so we can just let the ramps/floors get stamped
12. Stamp it <ENTER>, move up in z, stamp <ENTER>, etc. Unpause, let the dwarves build.

13. Now let's fix those 'scaffolding' floors. Open stamper.
  13a. Let's set the ramps to be deconstruct.  Press <c> to open the "Paste as" submenu.
  13b. Cycle ramps (<r> several times) to be Deconstruct.
  13c. Press <ESC> to exit this submenu
14. Stamp it <ENTER>, unpause, let the dwarves deconstruct.

15. Finalize the walls. Open stamper. Press (c) to open the "Paste as" submenu.
  15a. Cycle ramps (<r> several times) to be Walls.
  15b. Press <ESC> to exit this submenu
  15c. Cancel/deconstruct at least one wall on the ground floor as a door, or it's a sealed tower.
16. Stamp it <ENTER> and repeat on the above levels, unpause, let the dwarves build.

17. Let's build a quick path up to our tower. Open stamper
  17a. press <s> to start a new selection. We'll copy a 2x2 section of floor.
  17b. press <c> to select existing constructions
  17c. move to a spot of floor, press <ENTER> to mark, and move down and over to select a 2x2 section <ENTER>

18. Enable mouse input, <m> and dragging <n>
  NOTE: Lerping is interpolation as the mouse moves, but it's too slow to be useful most of the time.
  18a. click and drag (slowly) to paint constructions. Fancy.
  18b. Unpause and let them build.

19. Finished.

Ok, I hope you can see how this saves time when you have a lot of floors to do (you can do each stage for all floors at the same time), or a lot of funny corners to fix.



==== TROUBLESHOOTING ====

1. Only part of a design got placed as construction jobs!
  -You probably didn't have enough of the chosen material. It will just stop placing when it runs out.
  -You can just repeat the stamp when you have acquired more of that material, or change the material.

2. Things collapsed when I was building!
  -Either you placed constructions where they would have no support (like building walls off the middle of a bridge), or you removed support. Maybe you placed constructions in trees (don't do that).

3. I called gui/stamperc but the df window just went black
  -You can't call stamper from the Ctrl-Shift-P in game command prompt, use the dfhack console window.
  -Try pressing enter in the console, worst case if the stamper menu is shown but you can't exit: devel/pop-screen.

]]